package seg3x02.converter

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ConverterApplication

fun main(args: Array<String>) {
	runApplication<ConverterApplication>(*args)
}
